import React, { useState } from 'react';
import Header from './components/Header';
import QuestionForm from './components/QuestionForm';
import AnswerSection from './components/AnswerSection';

const App = () => {
  const [answer, setAnswer] = useState('');

  const handleSubmitQuestion = async (questionData) => {
    const aiResponse = await fetch('/api/answer', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(questionData)
    });
    const response = await aiResponse.json();
    setAnswer(response.answer);
  };

  return (
    <div>
      <Header />
      <section>
        <QuestionForm onSubmit={handleSubmitQuestion} />
        <AnswerSection answer={answer} />
      </section>
    </div>
  );
};

export default App;
