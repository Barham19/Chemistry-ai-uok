const AnswerSection = ({ answer }) => (
  <section>
    <h2>الجواب:</h2>
    <p>{answer || 'انتظر الحل...'} </p>
  </section>
);

export default AnswerSection;
