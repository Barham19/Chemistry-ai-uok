const Header = () => (
  <header>
    <h1>Barham ChemSolve AI</h1>
    <p>Designed & Programmed by Barham Sarkaut Saeed</p>
    <p>موقع لحل الأسئلة والواجبات في قسم الكيمياء بجامعة كركوك بدقة واحترافية</p>
  </header>
);

export default Header;
