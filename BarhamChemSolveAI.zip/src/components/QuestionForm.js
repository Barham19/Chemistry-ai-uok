import React, { useState } from 'react';

const QuestionForm = ({ onSubmit }) => {
  const [question, setQuestion] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ question });
    setQuestion('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <textarea 
        value={question} 
        onChange={(e) => setQuestion(e.target.value)} 
        placeholder="اكتب سؤالك هنا"
        required 
      />
      <button type="submit">حل السؤال</button>
    </form>
  );
};

export default QuestionForm;
