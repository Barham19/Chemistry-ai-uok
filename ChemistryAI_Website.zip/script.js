
function getAnswer() {
    const question = document.getElementById("questionInput").value;
    const answerBox = document.getElementById("answerBox");
    if (question.trim() === "") {
        answerBox.innerHTML = "<p>الرجاء كتابة سؤال.</p>";
        return;
    }
    // Simulated response
    answerBox.innerHTML = "<p><strong>سؤالك:</strong> " + question + "</p>" +
                          "<p><strong>الإجابة:</strong> سيتم دعم الذكاء الاصطناعي قريباً لتقديم إجابة دقيقة من مصادر كيميائية موثوقة.</p>";
}
